

public class Troop{
	int id;
	int life;
	String troop;
	public Troop(int l, int i){
		this.id = i;
		this.life = l;
	}
}