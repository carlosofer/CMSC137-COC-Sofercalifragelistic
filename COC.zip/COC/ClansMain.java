public class ClansMain {

	/**
	 * @param args
	 */
	// main class
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ClansWindow clan = new ClansWindow();
		clan.showWindow();
	}

}
